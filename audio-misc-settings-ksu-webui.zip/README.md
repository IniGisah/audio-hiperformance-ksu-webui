# Audio Misc. Settings + WebUI 🎧

A high-performance **KernelSU / MetaModule (OverlayFS & Magic Mount)** module engineered for audiophiles to unlock mastering-quality audio, reduce clock jitter, bypass Android system sound limiters, and monitor real-time audio sessions via an interactive WebUI.

---

## 🌟 Key Features & Audiophile Optimizations

1. **100 Volume Steps Control**:
   - Expands media volume steps from 15 to **100 steps** (~0.4–0.7 dB per step) for precise volume tuning on sensitive IEMs, headphones, and external speakers.

2. **Mastering-Quality Resampler (`AudioFlinger`)**:
   - Elevates Android OS mixer (`AudioFlinger`) resampler quality (`af.resampler.quality=7`, up to 194 dB stop-band attenuation & 520 half-filter length). Eliminates resampling distortion and aliasing artifacts across all playback apps.

3. **Direct Low-Jitter Audio Pass**:
   - Disables system-wide audio effects framework (`ro.audio.ignore_effects=true`), spatializers, and compression limiters (`soundfx`) to achieve a pure, direct bit-pass to your DAC.

4. **USB DAC & Hardware HAL Jitter Reduction**:
   - Scopes USB audio driver transfer periods (`vendor.audio.usb.perio=2000`) and USB period buffers (`vendor.audio.usb.out.period_us=2000`) to reduce phase jitter in external DAC PLL clocks without interfering with Bluetooth HCI buffers.

5. **Hi-Fi Pipeline & 24-bit FLAC Decoding**:
   - Enables 24-bit FLAC software decoding (`vendor.audio.flac.sw.decoder.24bit=true`), vendor Hi-Fi audio pipeline (`persist.vendor.audio.hifi=true`), and extends AudioFlinger standby timeout to prevent DAC clock power-cycling pops.

6. **Safety & Volume Dose Limiters Disabled**:
   - Bypasses Android safe volume warnings (`audio.safemedia.bypass=true`) and disables European sound dose limiters.

7. **System Bloatware & Dolby FX Removal**:
   - Automatically disables background jitter-inducing daemons (Moto Dolby DAX, Tensor AOC daemons, and Digital Wellbeing prebuilts).

---

## 📱 Interactive WebUI Control Panel

Access the built-in control panel directly from **KernelSU Manager**, **ZeroMount WebUI**, or **APatch**:

- 🎙️ **Live Hardware Output Route**: Real-time ALSA hardware proc validation (`/proc/asound/cards` & `/proc/asound/card*/stream0`). Instant fallback to **Built-in Speaker** upon unplugging external DACs.
- 🎛️ **USB DAC Diagnostics**: Displays connected DAC model name (e.g. *FiiO RETRO NANO*), hardware sample rate (96 kHz, 192 kHz, 384 kHz), format (PCM 24-bit/32-bit), and synchronization mode (`ASYNC`, `ADAPTIVE`, `SYNC`).
- 📶 **Dynamic Bluetooth Codec & Rate Detection**: Real-time parsing of active over-the-air Bluetooth codecs (**LDAC ~990 kbps @ 96 kHz**, **aptX Adaptive @ 48 kHz**, **aptX HD**, **AAC @ 44.1 kHz**, **SBC**).
- 🎚️ **Console Verbose Logs Toggle**: Built-in header toggle switch to filter low-level diagnostic logs or view full raw execution logs with persistent state saved in `localStorage`.
- ⚡ **1-Click Audioserver Restart**: Apply system property changes or audio policy updates instantly without rebooting your phone.

---

## 🛡️ Stealth & Anti-Detection (ZeroMount / Banking Apps)

- **Zero Mount Pollution**: Native OverlayFS nullification replaces soundfx libraries with 0-byte overlays during installation.
- **`myBCA` & Banking App Compatible**: Leaves **zero extra mount entries** in `/proc/self/mountinfo`.
- **No Extra Modules Required**: Fully standalone—**no need to install `compatible-magisk-mirroring`**.

---

## 💡 Audiophile Best Practices Guide

- **Bit-Perfect Playback**: For the highest fidelity, use player apps like **USB Audio Player PRO (UAPP)**, **HiBy Music**, or **Poweramp** with Direct Hi-Res output enabled.
- **Battery Optimization**: Change battery usage settings for your music player apps to **Unrestricted** (or "Don't optimize") to eliminate micro-stuttering caused by Android CPU scaling.
- **Disable Digital Wellbeing**: Uninstall or restrict the "Digital Wellbeing" system app to prevent background CPU interrupts during audio playback.

---

## 📊 Resampling Parameter Technical Reference

| Mode / Device Profile | Stop Band Attenuation | Half Filter Length | Cut-off Frequency | Notes |
| :--- | :---: | :---: | :---: | :--- |
| **AOSP Default** | 90 dB | 32 | 100% | Stock Android |
| **High Performance (A12+)** | **179 dB** | **408** | **99%** | Master Quality |
| **Very High Performance (Snapdragon 8 Gen 2/3/4, Tensor)** | **194 dB** | **520** | **98%** | Maximum Precision |

---

## 🔧 Installation & Safe Mode Recovery

1. **Installation**:
   - Flash `audio-misc-settings-ksu-webui.zip` in **KernelSU Manager**, **KernelSU Next**, or **APatch**.
   - Reboot your device.

2. **Bootloop Safe Mode**:
   - If a conflict occurs with another audio mod, hold **Volume Down** during boot to trigger KernelSU Safe Mode, or remove `/data/adb/modules/audio-misc-settings-ksu-webui` via TWRP/recovery.

---

## 📄 License & Disclaimer

Provided as-is for audiophiles and music lovers. Flash at your own choice.
